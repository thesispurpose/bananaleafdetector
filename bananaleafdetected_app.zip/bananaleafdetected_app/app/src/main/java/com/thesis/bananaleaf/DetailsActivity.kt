package com.thesis.bananaleaf

import android.graphics.BitmapFactory
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.thesis.bananaleaf.databinding.ActivityDetailsBinding
import java.util.Locale

/** Full-screen details page for the complete result of the current scan. */
class DetailsActivity : AppCompatActivity() {
    companion object {
        const val EXTRA_IMAGE_PATH = "details_image_path"
        const val EXTRA_DISEASE_NAME = "details_disease_name"
        const val EXTRA_CONFIDENCE = "details_confidence"
        const val EXTRA_DISEASE_NAMES = "details_disease_names"
        const val EXTRA_DISEASE_CONFIDENCES = "details_disease_confidences"
        const val EXTRA_HEALTHY_CONFIDENCE = "details_healthy_confidence"

        fun launch(
            context: android.content.Context,
            imagePath: String,
            diseaseNames: ArrayList<String>,
            diseaseConfidences: FloatArray,
            healthyConfidence: Float
        ) {
            val intent = android.content.Intent(context, DetailsActivity::class.java).apply {
                putExtra(EXTRA_IMAGE_PATH, imagePath)
                putStringArrayListExtra(EXTRA_DISEASE_NAMES, diseaseNames)
                putExtra(EXTRA_DISEASE_CONFIDENCES, diseaseConfidences)
                putExtra(EXTRA_HEALTHY_CONFIDENCE, healthyConfidence)
            }
            context.startActivity(intent)
        }
    }

    private lateinit var binding: ActivityDetailsBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        intent.getStringExtra(EXTRA_IMAGE_PATH)?.let { path ->
            BitmapFactory.decodeFile(path)?.let { bitmap ->
                binding.diseaseImage.setImageBitmap(bitmap)
            }
        }

        val names = intent.getStringArrayListExtra(EXTRA_DISEASE_NAMES)
            ?: arrayListOf(intent.getStringExtra(EXTRA_DISEASE_NAME).orEmpty().ifBlank { "Healthy" })
        val confidences = intent.getFloatArrayExtra(EXTRA_DISEASE_CONFIDENCES)
            ?: floatArrayOf(intent.getFloatExtra(EXTRA_CONFIDENCE, 0f))
        val healthyConfidence = intent.getFloatExtra(EXTRA_HEALTHY_CONFIDENCE, 0f).coerceIn(0f, 1f)
        val isHealthy = names.size == 1 && names[0] == "Healthy"

        val detailsList = names.map { DiseaseInfo.get(it) }

        binding.titleText.text = getString(R.string.disease_details_title)
        // Single result (healthy or one disease) reads as "Name - XX.X%",
        // matching the reference pill; multiple diseases just list the names
        // since a single percentage wouldn't represent all of them.
        binding.diseaseName.text = when {
            isHealthy -> {
                val pct = String.format(Locale.US, "%.1f", healthyConfidence * 100f)
                "${detailsList.first().displayName} - $pct%"
            }
            detailsList.size == 1 -> {
                val pct = String.format(
                    Locale.US, "%.1f", (confidences.getOrNull(0)?.coerceIn(0f, 1f) ?: 0f) * 100f
                )
                "${detailsList.first().displayName} - $pct%"
            }
            else -> detailsList.joinToString(" + ") { it.displayName }
        }
        // Box color reflects the outcome: green for healthy, red for a detected disease.
        if (isHealthy) {
            binding.diseaseName.setBackgroundResource(R.drawable.bg_disease_name_chip_healthy)
            binding.diseaseName.setTextColor(resources.getColor(R.color.leaf_green_dark, theme))
        } else {
            binding.diseaseName.setBackgroundResource(R.drawable.bg_disease_name_chip)
            binding.diseaseName.setTextColor(android.graphics.Color.parseColor("#B3261E"))
        }

        binding.confidenceText.text = if (isHealthy) {
            getString(
                R.string.detection_confidence_format,
                String.format(Locale.US, "%.1f", healthyConfidence * 100f)
            )
        } else {
            detailsList.mapIndexed { index, details ->
                val confidence = confidences.getOrNull(index)?.coerceIn(0f, 1f) ?: 0f
                "${details.displayName}: ${String.format(Locale.US, "%.1f", confidence * 100f)}%"
            }.joinToString("\n")
        }

        binding.descriptionText.text = detailsList
            .map { details ->
                "${details.displayName}\n${details.overview}\n\nIdentified Symptoms\n" +
                    details.symptoms.joinToString("\n") { "• $it" }
            }
            .joinToString("\n\n")

        binding.treatmentHeader.text = if (isHealthy) {
            getString(R.string.recommendation_header)
        } else {
            getString(R.string.treatment_recommendation_header)
        }
        binding.preventionHeader.text = if (isHealthy) {
            getString(R.string.healthy_leaf_care_header)
        } else {
            getString(R.string.prevention_management_header)
        }

        binding.treatmentText.text = detailsList
            .flatMap { details ->
                listOf(details.displayName) + details.treatment.map { "• $it" }
            }.joinToString("\n\n")

        binding.preventionText.text = detailsList
            .flatMap { details ->
                listOf(details.displayName) + details.recommendations.map { "• $it" }
            }.joinToString("\n\n")

        binding.backButton.setOnClickListener { onBackPressedDispatcher.onBackPressed() }

        // Bottom nav mirrors the scanner screen. Home just returns to the
        // already-running scanner underneath; the other three tell that
        // MainActivity instance which section to open as soon as it resumes.
        binding.navHome.setOnClickListener { finish() }
        binding.navGarden.setOnClickListener {
            MainActivity.pendingSectionToOpen = "garden"
            finish()
        }
        binding.navDiscover.setOnClickListener {
            MainActivity.pendingSectionToOpen = "discover"
            finish()
        }
        binding.navAccount.setOnClickListener {
            MainActivity.pendingSectionToOpen = "lgu"
            finish()
        }
    }
}
