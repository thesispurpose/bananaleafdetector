package com.thesis.bananaleaf

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.animation.ObjectAnimator
import android.animation.AnimatorSet
import android.animation.ValueAnimator
import android.view.View
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity

@Suppress("CustomSplashScreen")
class SplashActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)

        val scanLine = findViewById<View>(R.id.scanLine)
        val logoContainer = findViewById<View>(R.id.logoContainer)
        val logoImage = findViewById<ImageView>(R.id.logoImage)

        logoContainer.post {
            // Scan line animation (up and down)
            val scanAnimator = ObjectAnimator.ofFloat(
                scanLine,
                "translationY",
                0f,
                logoContainer.height.toFloat()
            )
            scanAnimator.duration = 1000
            scanAnimator.repeatCount = ValueAnimator.INFINITE
            scanAnimator.repeatMode = ValueAnimator.REVERSE

            // Flash/glow effect sa logo — pumapalit ang opacity
            val flashAnimator = ObjectAnimator.ofFloat(
                logoImage,
                "alpha",
                1f,
                0.4f
            )
            flashAnimator.duration = 500
            flashAnimator.repeatCount = ValueAnimator.INFINITE
            flashAnimator.repeatMode = ValueAnimator.REVERSE

            // Patakbuhin nang sabay
            val animatorSet = AnimatorSet()
            animatorSet.playTogether(scanAnimator, flashAnimator)
            animatorSet.start()
        }

        Handler(Looper.getMainLooper()).postDelayed({
            startActivity(Intent(this, MainActivity::class.java))
            finish()
        }, 2500)
    }
}
