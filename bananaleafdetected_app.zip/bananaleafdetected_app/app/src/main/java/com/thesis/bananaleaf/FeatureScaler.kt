package com.thesis.bananaleaf

/**
 * StandardScalers exported from the current BananaLeaf training notebook.
 * The leaf gate uses its own 10-feature scaler; disease heads use their own
 * 15-feature scaler.
 */
object FeatureScaler {
    private val LEAF_MEAN = doubleArrayOf(
        0.820215451958853,
        0.5284772095788721,
        0.7966747236813374,
        1.0679864195766793,
        0.8494039610947778,
        42.20490018056468,
        17.973289093197877,
        115.88293079448503,
        144.29852866601067,
        0.03931312103304872
    )

    private val LEAF_SCALE = doubleArrayOf(
        0.23923438032114064,
        0.2517718197799668,
        0.28027248832017204,
        0.39828611813368364,
        0.19177860594102925,
        12.935974007830822,
        15.833014550724567,
        62.74734471097486,
        21.610979346985236,
        0.033448046613478
    )

    private val DISEASE_MEAN = doubleArrayOf(
        38.92392158411554,
        8.920379662086685,
        -0.3094841305959873,
        122.72799990766005,
        34.12925175807139,
        -0.12372661115108279,
        143.72066123083678,
        26.541600405269612,
        3.111977447061652,
        1.9648618098163033,
        0.8097389864475063,
        0.6841080827521578,
        0.14013074431417005,
        0.9751707185963832,
        0.022261675133076513
    )

    private val DISEASE_SCALE = doubleArrayOf(
        10.185584948281294,
        5.910325275680441,
        9.359788204802962,
        59.760218912122475,
        16.850502914162266,
        32.857076232090336,
        19.995707828468955,
        9.824417041280652,
        22.617065038069352,
        1.2220659743013866,
        0.2733491776301369,
        0.07861991886340389,
        0.04830219966290254,
        0.014528391373487265,
        0.017631675435600676
    )

    fun transformLeaf(features: DoubleArray): DoubleArray =
        transform(features, LEAF_MEAN, LEAF_SCALE)

    fun transformDisease(features: DoubleArray): DoubleArray =
        transform(features, DISEASE_MEAN, DISEASE_SCALE)

    private fun transform(
        features: DoubleArray,
        mean: DoubleArray,
        scale: DoubleArray
    ): DoubleArray {
        require(features.size == mean.size) {
            "Expected ${mean.size} features, got ${features.size}"
        }
        return DoubleArray(features.size) { i -> (features[i] - mean[i]) / scale[i] }
    }
}
