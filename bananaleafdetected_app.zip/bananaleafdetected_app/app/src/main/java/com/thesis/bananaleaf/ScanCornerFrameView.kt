package com.thesis.bananaleaf

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View

/**
 * Draws four open corner brackets (top-left, top-right, bottom-left,
 * bottom-right), like a camera viewfinder/scan reticle, instead of a solid
 * rounded-rectangle border. This matches the reference scanning UI where the
 * frame is only marked at its corners so the leaf underneath stays fully
 * visible.
 *
 * The bracket color is swapped at runtime (green when a banana leaf is
 * present, red when it is not) via [cornerColor], mirroring the same signal
 * that used to drive the old solid-border stroke color.
 */
class ScanCornerFrameView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    private val strokeWidthPx = 3f * resources.displayMetrics.density
    private val cornerLengthPx = 26f * resources.displayMetrics.density
    private val insetPx = 2f * resources.displayMetrics.density

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = strokeWidthPx
        strokeCap = Paint.Cap.ROUND
        color = Color.parseColor("#32CD32")
    }

    /** Color of all four corner brackets. Setting this redraws the view. */
    var cornerColor: Int
        get() = paint.color
        set(value) {
            if (paint.color != value) {
                paint.color = value
                invalidate()
            }
        }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val left = insetPx
        val top = insetPx
        val right = width - insetPx
        val bottom = height - insetPx
        val len = cornerLengthPx.coerceAtMost((right - left) / 2.5f)

        // Top-left
        canvas.drawLine(left, top, left + len, top, paint)
        canvas.drawLine(left, top, left, top + len, paint)
        // Top-right
        canvas.drawLine(right, top, right - len, top, paint)
        canvas.drawLine(right, top, right, top + len, paint)
        // Bottom-left
        canvas.drawLine(left, bottom, left + len, bottom, paint)
        canvas.drawLine(left, bottom, left, bottom - len, paint)
        // Bottom-right
        canvas.drawLine(right, bottom, right - len, bottom, paint)
        canvas.drawLine(right, bottom, right, bottom - len, paint)
    }
}
