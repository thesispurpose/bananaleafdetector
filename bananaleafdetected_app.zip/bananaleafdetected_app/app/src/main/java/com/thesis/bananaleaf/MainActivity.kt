package com.thesis.bananaleaf

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.ImageFormat
import android.graphics.Matrix
import android.graphics.Rect
import android.graphics.YuvImage
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.SystemClock
import android.content.SharedPreferences
import android.speech.tts.TextToSpeech
import android.speech.tts.Voice
import android.widget.Toast
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.drawable.ColorDrawable
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import com.google.android.material.card.MaterialCardView
import com.google.android.material.imageview.ShapeableImageView
import com.google.android.material.shape.ShapeAppearanceModel
import com.thesis.bananaleaf.databinding.ActivityMainBinding
import org.opencv.android.OpenCVLoader
import org.opencv.android.Utils
import org.opencv.core.Mat
import org.opencv.imgproc.Imgproc
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

/**
 * A single shadow-boxed card inside an in-app info section (App Guide, My
 * Garden, About, LGU Connect). [header] is optional -- omit it for a card
 * that is just a paragraph with no heading, matching the reference screens
 * where the very first paragraph under a section title has no header of
 * its own. [plainLabel] renders as small unboxed caption text above a card
 * instead of a card itself (e.g. "BananaleafDetector Purpose").
 */
private sealed class SectionBlock {
    data class Card(val header: String?, val body: String) : SectionBlock()
    data class PlainLabel(val text: String) : SectionBlock()
}

/**
 * One saved scan in My Garden: the leaf photo plus everything needed to
 * both render the history card (status pill, condition + confidence,
 * confidence banner) and reopen the exact same full result in
 * [DetailsActivity] later, without re-running the model.
 *
 * Serialized as a single "|"-delimited string so it can live inside a
 * SharedPreferences string set:
 *   imagePath|diseaseKeysCsv|confidencesCsv|healthyConfidence|timestamp
 * [diseaseNames] is empty for a healthy result. [confidences] lines up
 * 1:1 with [diseaseNames] by index.
 */
private data class GardenEntry(
    val imagePath: String,
    val diseaseNames: List<String>,
    val confidences: List<Float>,
    val healthyConfidence: Float,
    val timestamp: Long
) {
    val isHealthy: Boolean get() = diseaseNames.isEmpty()

    fun serialize(): String {
        val namesCsv = diseaseNames.joinToString(",")
        val confCsv = confidences.joinToString(",")
        return "$imagePath|$namesCsv|$confCsv|$healthyConfidence|$timestamp"
    }

    companion object {
        /** Returns null for a corrupt/unreadable entry so callers can just filter it out. */
        fun parse(raw: String): GardenEntry? {
            val parts = raw.split("|")
            if (parts.isEmpty() || parts[0].isBlank()) return null
            val imagePath = parts[0]
            return if (parts.size >= 5) {
                val names = parts[1].split(",").filter { it.isNotBlank() }
                val confidences = parts[2].split(",").mapNotNull { it.toFloatOrNull() }
                val healthy = parts[3].toFloatOrNull() ?: 0f
                val stamp = parts[4].toLongOrNull() ?: 0L
                GardenEntry(imagePath, names, confidences, healthy, stamp)
            } else {
                // Entries saved by an older version of the app, before
                // confidences/healthyConfidence were recorded:
                // "imagePath|diseaseNamesOrHealthyLeafLabel|timestamp".
                // Shown with the condition name but no percentage.
                val legacyLabel = parts.getOrNull(1)?.split(",")?.filter { it.isNotBlank() } ?: emptyList()
                val names = if (legacyLabel == listOf("Healthy Leaf")) emptyList() else legacyLabel
                val stamp = parts.getOrNull(2)?.toLongOrNull() ?: 0L
                GardenEntry(imagePath, names, emptyList(), 0f, stamp)
            }
        }
    }
}

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private var imageCapture: ImageCapture? = null

    // Four independent binary models replace the old single 4-class forest:
    // one gate (is this even a banana leaf?) and three disease-presence
    // checks that each run regardless of what the others say -- so a leaf
    // with two or three diseases at once gets all of them flagged, instead
    // of the old single-label model being forced to pick just one.
    private lateinit var leafModel: RandomForestModel
    private lateinit var cordanaModel: RandomForestModel
    private lateinit var pestalotiopsisModel: RandomForestModel
    private lateinit var sigatokaModel: RandomForestModel

    // --- Flash/torch state ---
    private var camera: Camera? = null
    private var isFlashOn = false

    // --- Live/continuous scanning (runs the same model pipeline as a real
    // shutter-triggered scan on a throttled stream of camera frames, so the
    // status pill / scan-frame color update while you're just panning
    // around, the way the reference "Leaf in focus" screens do) ---
    private val cameraExecutor: ExecutorService = Executors.newSingleThreadExecutor()

    // A frame is dropped (not queued) whenever the previous one is still
    // being processed, so the live update rate self-throttles to whatever
    // this specific device's real RF-plus-GLCM inference speed is instead
    // of building up a backlog of stale frames.
    private val liveAnalysisBusy = AtomicBoolean(false)

    // True from the moment the shutter is tapped until the user dismisses
    // the result (resetScannerForNewScan()). Live analysis keeps running
    // underneath so the border color is already right the instant the user
    // goes back to scanning, but it stops overwriting detectionTitle/
    // detectionConfidence/detectionHealth while a locked-in, saved result
    // is what's actually on screen.
    @Volatile
    private var showingCapturedResult = false

    // Frozen copy of the last captured photo, shown in capturedFreezeFrame
    // over the live camera preview while a scan's result is up (this is a
    // separate copy from the bitmap runInference() processes/recycles, so
    // recycling that one on the background thread never touches what's on
    // screen).
    private var freezeFrameBitmap: Bitmap? = null

    // Last completed scan, so VIEW MORE DETAILS can reopen the actual result.
    private var lastResultPath: String = ""
    private var lastDiseaseNames: ArrayList<String> = arrayListOf()
    private var lastDiseaseConfidences: FloatArray = floatArrayOf()
    private var lastHealthyConfidence: Float = 0f

    // Persistent collection storage: saved scans survive app restarts.
    private lateinit var collectionPrefs: SharedPreferences
    private val collectionKey = "saved_scans"

    // Result sheet: hidden until a real result exists, then shown as a small
    // white peek bar controlled entirely by taps.
    private var resultSheetExpanded = false

    // Reads the result aloud when the speaker button (next to the title) is tapped.
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var lastDetectedSpokenText: String = ""

    // Internal key (e.g. "Sigatoka", "Healthy") of the top/highest-confidence
    // result from the last scan, used to look up the Tagalog text that gets
    // read aloud for whichever tab is tapped -- kept separate from the
    // on-screen (English) result text.
    private var lastTopResultKey: String = "Healthy"

    // Which result tab (0 = Disease, 1 = Treatment, 2 = Recommendations) is
    // currently open, so the speaker button reads THAT tab's content instead
    // of always reading a fixed summary.
    private var currentResultTab: Int = 0

    companion object {
        // Thresholds exported from the validation split of the supplied
        // bananaLeaf_MULTILABEL_DETECTION training pipeline.
        // Thresholds from model_metadata.json in BananaLeaf_Training.zip.
        //
        // Raised from the original 0.5 (model_metadata.json default) to 0.90
        // on 2026-09-15 after sweeping leaf_detector.bin's actual output
        // against the full training set (700 real-leaf, 213 NEGATIVE
        // images):
        //   threshold=0.50 -> leaf recall 99.6%  not-leaf false-accept 16.4%
        //   threshold=0.70 -> leaf recall 99.0%  not-leaf false-accept  5.6%
        //   threshold=0.80 -> leaf recall 99.0%  not-leaf false-accept  2.4%
        //   threshold=0.90 -> leaf recall 97.1%  not-leaf false-accept  0.9%
        //   threshold=0.95 -> leaf recall 95.1%  not-leaf false-accept  0.5%  <- chosen
        // Raised again from 0.90 to 0.95 on 2026-09-19 after field testing
        // showed everyday objects (a speaker, a broom against a wall) still
        // scoring 90-92% leaf-probability -- just above the old 0.90 cutoff
        // -- and being misread as banana leaves. 0.95 pushes both of those
        // observed false-accepts back under the cutoff. This is still a
        // stopgap: the model's NEGATIVE training set only covers 4 narrow
        // subcategories (other_plant, background, objects, person) and has
        // never specifically seen things like speakers or brooms, so other
        // untrained object types can still slip through occasionally. The
        // real fix is adding more varied NEGATIVE photos (random household
        // objects, not just the 4 existing subfolders) before the next
        // retrain -- see training-notebooks/README.md. NOTE: this no longer
        // matches model_metadata.json's leaf_gate_threshold (0.5) -- that
        // file still reflects the original export and was intentionally
        // left as-is; this constant is the one actually used at runtime.
        const val LEAF_PRESENT_THRESHOLD = 0.95f

        // ---- Rule-based safety net (no dataset/retrain needed) ----
        // The learned leaf-gate model was trained on only 217 NEGATIVE
        // (not-leaf) images across 4 narrow subcategories (other_plant,
        // background, objects, person) -- it has never seen fabric/curtains/
        // cloth, so a colorful textured object can still slip past leafProb
        // >= LEAF_PRESENT_THRESHOLD. veg_ratio (the fraction of pixels that
        // fall inside the green-vegetation HSV mask) is cheap, doesn't need
        // any training data, and is extremely reliable on the training set:
        // real banana leaf photos are almost always well above 0.10
        // (measured 0% false-reject rate on 400 real leaf training images
        // at this cutoff), while a satin-curtain test capture measured only
        // 0.037. This check runs in ADDITION to the ML leaf-gate, not
        // instead of it, so it only ever makes the gate stricter.
        const val VEG_RATIO_MIN_THRESHOLD = 0.10f

        // Below this, a SINGLE LABEL disease result is still shown but
        // flagged as low-confidence instead of presented as a firm
        // diagnosis. The Sigatoka result that inspired this was 0.55 --
        // literally one point above its own 0.55 threshold, i.e. barely
        // more likely than not, not a confident call.
        const val LOW_CONFIDENCE_THRESHOLD = 0.65f

        // Re-tuned for the 2026-09-13 retrain (model.zip / training_summary.json).
        // Same spread as before (0.55 / 0.60 / 0.65: weakest head gets the
        // highest threshold to suppress its extra false positives, strongest
        // head gets the lowest), but reassigned to match THIS model's actual
        // per-disease f1 from training_summary.json, which flipped which head
        // is weakest: Sigatoka is now strongest (f1 0.93), Pestalotiopsis is
        // next (f1 0.7616), Cordana is now weakest (f1 0.7411) -- the previous
        // retrain had it the other way around (Sigatoka weakest, Pestalotiopsis
        // strongest), and these three constants had been left matching that
        // old ranking. No per-class precision-at-0.5 breakdown is available
        // for this retrain (model_report.txt only has accuracy/f1), so this
        // is a principled reordering, not a re-derived PR-curve sweep -- treat
        // these as a reasonable default and re-tune from a real PR curve if
        // false positive/negative rates in the field say otherwise.
        const val CORDANA_THRESHOLD = 0.65f
        const val SIGATOKA_THRESHOLD = 0.55f
        const val PESTALOTIOPSIS_THRESHOLD = 0.60f

        // Set by DetailsActivity's bottom nav so that, after returning to
        // this (already-running) MainActivity instance, the requested
        // section opens automatically instead of just landing back on the
        // scanner. Cleared as soon as it's consumed in onResume().
        var pendingSectionToOpen: String? = null
    }

    private val requestPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) startCamera() else {
                Toast.makeText(this, R.string.camera_permission_required, Toast.LENGTH_LONG).show()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        collectionPrefs = getSharedPreferences("leafdetector_collection", MODE_PRIVATE)

        // Blur the live camera everywhere outside the scan frame. The frame
        // itself is a cutout in MaskedBlurView, so the leaf stays sharp.
        binding.blurOutsideFrame.setCutoutView(binding.scanFrame)
        binding.blurOutsideFrame.setupWith(binding.cameraBlurTarget)
            .setBlurRadius(18f)
            .setBlurAutoUpdate(true)
            .setOverlayColor(0x42000000)

        if (!OpenCVLoader.initLocal()) {
            Toast.makeText(this, R.string.opencv_init_failed, Toast.LENGTH_LONG).show()
        }

        // Loaded once here and reused for every photo -- each is a small,
        // independent forest (see RandomForestModel).
        leafModel = RandomForestModel.loadFromAssets(this, "leaf_detector.bin", listOf("NotLeaf", "Leaf"))
        cordanaModel = RandomForestModel.loadFromAssets(this, "cordana.bin", listOf("Absent", "Cordana"))
        pestalotiopsisModel = RandomForestModel.loadFromAssets(this, "pestalotiopsis.bin", listOf("Absent", "Pestalotiopsis"))
        sigatokaModel = RandomForestModel.loadFromAssets(this, "sigatoka.bin", listOf("Absent", "Sigatoka"))

        // Offline text-to-speech for the "read result aloud" speaker button.
        // Spoken result is Tagalog, so the engine's voice is set to Filipino
        // (fil-PH) when the device has that voice installed; if it doesn't,
        // fall back to the device's default voice so speech still works
        // (it will just read the Tagalog text with non-Filipino pronunciation).
        tts = TextToSpeech(this) { status ->
            ttsReady = status == TextToSpeech.SUCCESS
            if (ttsReady) {
                val tagalog = java.util.Locale("fil", "PH")
                val availability = tts?.isLanguageAvailable(tagalog) ?: TextToSpeech.LANG_NOT_SUPPORTED
                tts?.language = if (availability >= TextToSpeech.LANG_AVAILABLE) tagalog else java.util.Locale.getDefault()
                selectNaturalMaleVoice()
            }
        }
        binding.speakResultButton.setOnClickListener { speakCurrentResult() }

        binding.captureButton.setOnClickListener { capturePhoto() }

        // Result toolbar tabs. The sheet is hidden until a successful scan.
        binding.tabDisease.setOnClickListener { selectResultTab(0) }
        binding.tabTreatment.setOnClickListener { selectResultTab(1) }
        binding.tabRecommendations.setOnClickListener { selectResultTab(2) }
        hideResultSheet()
        setupResultSheetClicks()

        // Navigation controls open real in-app sections instead of only showing a Toast.
        binding.settingsButton.setOnClickListener {
            showSection(
                "App Guide",
                listOf(
                    SectionBlock.Card(null, "How to use BananaLeafDetector"),
                    SectionBlock.Card(
                        "1. SCAN A LEAF",
                        "Tap the camera button, then place one banana leaf inside the scan frame. Use good lighting and keep the leaf centered."
                    ),
                    SectionBlock.Card(
                        "2. READ THE RESULT",
                        "After scanning, tap the white result panel to open it. Tap the camera area to close the result and prepare for another scan. Use Disease, Treatment, and Recommendations to view each section."
                    ),
                    SectionBlock.Card(
                        "3. SCAN AGAIN",
                        "Tap GO TO HOME or the camera button to return to the scanner and prepare for another leaf."
                    ),
                    SectionBlock.Card(
                        "4. NAVIGATION",
                        "Home opens the scanner. My Garden is for saved scans. Discover contains banana-leaf disease information. LGU Connect shows how to reach your Local Government Unit for further help."
                    ),
                    SectionBlock.Card(
                        "5. FLASH",
                        "Use the flash button when more light is needed."
                    ),
                    SectionBlock.Card(null, "Note: The leaf analysis runs offline on this device.")
                ),
                "GO TO HOME"
            ) { resetScannerForNewScan() }
        }
        binding.viewDetailsButton.setOnClickListener {
            if (lastResultPath.isNotEmpty()) {
                DetailsActivity.launch(
                    this,
                    lastResultPath,
                    lastDiseaseNames,
                    lastDiseaseConfidences,
                    lastHealthyConfidence
                )
            } else {
                Toast.makeText(this, "Scan a leaf first to view the full leaf analysis.", Toast.LENGTH_SHORT).show()
            }
        }
        binding.addCollectionButton.setOnClickListener {
            saveCurrentScanToCollection()
        }
        binding.navHome.setOnClickListener { resetScannerForNewScan() }
        binding.navGarden.setOnClickListener { showGardenSection() }
        binding.navDiscover.setOnClickListener {
            showSection(
                "About BananaleafDetector",
                listOf(
                    SectionBlock.Card(
                        null,
                        "BananaleafDetector is an offline mobile app designed to help users screen banana leaves for possible health conditions using image analysis and trained models."
                    ),
                    SectionBlock.Card(
                        "WHAT THE APP DOES",
                        "• Scans a banana leaf using the phone camera.\n" +
                            "• First checks whether the image contains a banana leaf.\n" +
                            "• Screens for several common banana leaf conditions covered by the app.\n" +
                            "• Can report more than one possible condition on the same leaf.\n" +
                            "• Shows confidence estimates, treatment guidance, and prevention recommendations.\n" +
                            "• Lets you save completed scans in My Garden for later review."
                    ),
                    SectionBlock.Card(
                        "HOW TO GET BETTER RESULTS",
                        "Use good lighting, keep the leaf centered inside the frame, and avoid heavily blurred or obstructed photos. The analysis runs offline on the device."
                    ),
                    SectionBlock.Card(
                        "IMPORTANT",
                        "The result is an image-based leaf screening estimate and is not a laboratory diagnosis. Use the information as a guide and confirm uncertain cases with a qualified agricultural professional."
                    )
                ),
                "BACK TO SCANNER"
            ) { hideSection() }
        }
        binding.navAccount.setOnClickListener {
            showSection(
                "Connected to LGU",
                listOf(
                    SectionBlock.PlainLabel("BananaleafDetector Purpose"),
                    SectionBlock.Card(
                        null,
                        "BananaLeafDetector is designed to help users scan banana leaves and identify possible leaf health conditions using an offline leaf analysis model."
                    ),
                    SectionBlock.Card(
                        "Purpose:",
                        "• Check whether the image contains a banana leaf.\n" +
                            "• Screen for possible visual symptoms of common leaf conditions covered by the app.\n" +
                            "• Provide treatment and care recommendations for reference.\n" +
                            "• Save scan results in My Garden for later review."
                    ),
                    SectionBlock.Card(
                        null,
                        "The app is an assistive screening tool and should not replace professional agricultural diagnosis."
                    ),
                    SectionBlock.Card(
                        "NEED MORE HELP WITH YOUR BANANA CROP?",
                        "For a confirmed diagnosis, local treatment guidance, or planting assistance, connect with:\n\n" +
                            "Office of the Provincial Agriculturist\n" +
                            "Batangas Provincial Government\n" +
                            "Diversion Road, Bolbok, Batangas City\n\n" +
                            "Phone: (043) 740-4980 / 722-2207 / 722-2075\n" +
                            "Email: agri@batangas.gov.ph\n" +
                            "Facebook: facebook.com/OPABatangasOfficial\n\n" +
                            "If you're outside Batangas Province, visit or call your own city/municipal Agriculture Office (Municipal or City Agriculturist's Office) instead. They can provide on-site inspection, certified advice, and access to local farmer support programs."
                    )
                ),
                "BACK TO HOME"
            ) { hideSection() }
        }
        binding.sectionClose.setOnClickListener { hideSection() }
        binding.sectionActionButton.setOnClickListener { hideSection() }

        // Matches the "NO BANANA LEAF DETECTED" default text set in the
        // layout, instead of the layout's own hardcoded green -- red until
        // the first live frame (or a real scan) says otherwise.
        applyStatusColor(leafPresent = false, hasDisease = false)

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            == PackageManager.PERMISSION_GRANTED
        ) {
            startCamera()
        } else {
            requestPermissionLauncher.launch(Manifest.permission.CAMERA)
        }
        keepCaptureButtonOnTop()
    }

    private fun saveCurrentScanToCollection() {
        if (lastResultPath.isEmpty()) {
            Toast.makeText(this, "Scan a banana leaf first.", Toast.LENGTH_SHORT).show()
            return
        }

        val source = File(lastResultPath)
        if (!source.exists()) {
            Toast.makeText(this, "The scan image is no longer available. Please scan again.", Toast.LENGTH_SHORT).show()
            return
        }

        val stamp = System.currentTimeMillis()
        val savedFile = File(filesDir, "collection_leaf_$stamp.jpg")
        source.copyTo(savedFile, overwrite = true)

        val entry = GardenEntry(
            imagePath = savedFile.absolutePath,
            diseaseNames = lastDiseaseNames.toList(),
            confidences = lastDiseaseConfidences.toList(),
            healthyConfidence = lastHealthyConfidence,
            timestamp = stamp
        )
        val existing = (collectionPrefs.getStringSet(collectionKey, emptySet()) ?: emptySet()).toMutableSet()
        existing.add(entry.serialize())
        collectionPrefs.edit().putStringSet(collectionKey, existing).apply()

        binding.addCollectionButton.text = "SAVED TO COLLECTION"
        Toast.makeText(this, "Saved to My Garden.", Toast.LENGTH_SHORT).show()
    }

    /** Opens My Garden as a stack of photo history cards (see [buildGardenCards]),
     *  matching the reference "saved scan" cards -- image, date, status pill,
     *  condition + confidence, a Scan Again / Delete row per card -- instead
     *  of the plain text list used elsewhere in this screen's info sections. */
    private fun showGardenSection() {
        binding.sectionTitle.text = "My Garden"
        binding.sectionActionButton.text = "SCAN A LEAF"
        buildGardenCards()
        binding.sectionPanel.visibility = android.view.View.VISIBLE
        binding.captureButtonRing.visibility = android.view.View.GONE
        binding.sectionActionButton.setOnClickListener { hideSection(); resetScannerForNewScan() }
    }

    /** Reads every saved scan from [collectionPrefs], newest first, and
     *  renders each as its own photo history card directly into
     *  sectionCardsContainer (bypassing the plain-text SectionBlock cards
     *  used by the other info sections). */
    private fun buildGardenCards() {
        val container = binding.sectionCardsContainer
        container.removeAllViews()
        val density = resources.displayMetrics.density
        fun dp(value: Int) = (value * density).toInt()

        val rawEntries = (collectionPrefs.getStringSet(collectionKey, emptySet()) ?: emptySet())
        val parsedEntries = rawEntries.mapNotNull { raw -> GardenEntry.parse(raw)?.let { raw to it } }
            .sortedByDescending { it.second.timestamp }

        if (parsedEntries.isEmpty()) {
            val emptyCard = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setBackgroundResource(R.drawable.bg_shadow_card)
                elevation = dp(3).toFloat()
                setPadding(dp(18), dp(16), dp(18), dp(16))
                addView(TextView(this@MainActivity).apply {
                    text = "Your saved banana leaf scans will appear here.\n\nNo saved scans yet. After every successful scan, tap ADD TO COLLECTION to keep a copy in My Garden."
                    setTextColor(android.graphics.Color.parseColor("#222222"))
                    textSize = 14f
                    setLineSpacing(dp(4).toFloat(), 1f)
                    typeface = android.graphics.Typeface.create(android.graphics.Typeface.SERIF, android.graphics.Typeface.NORMAL)
                })
            }
            container.addView(emptyCard)
            return
        }

        val dateFormat = SimpleDateFormat("MMM d, yyyy | h:mm a", Locale.US)
        parsedEntries.forEach { (raw, entry) ->
            container.addView(buildGardenCard(raw, entry, dateFormat, ::dp))
        }
    }

    /** Builds one white shadow-boxed "saved scan" card: photo + date + status
     *  pill up top, condition/summary line with a chevron into the full
     *  details, a confidence banner for disease results, then a divider and
     *  a Scan Again / Delete row -- matching the reference My Garden cards. */
    private fun buildGardenCard(
        raw: String,
        entry: GardenEntry,
        dateFormat: SimpleDateFormat,
        dp: (Int) -> Int
    ): View {
        val details = entry.diseaseNames.map { DiseaseInfo.get(it) }

        fun openDetails() {
            DetailsActivity.launch(
                this,
                entry.imagePath,
                ArrayList(entry.diseaseNames),
                entry.confidences.toFloatArray(),
                entry.healthyConfidence
            )
        }

        val card = MaterialCardView(this).apply {
            radius = dp(18).toFloat()
            cardElevation = dp(3).toFloat()
            setCardBackgroundColor(android.graphics.Color.WHITE)
            strokeWidth = 0
            val params = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            params.bottomMargin = dp(16)
            layoutParams = params
        }

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(14))
        }

        // --- Row 1: photo thumbnail, date, status pill ---
        val topRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
        }
        val thumb = ShapeableImageView(this).apply {
            layoutParams = LinearLayout.LayoutParams(dp(56), dp(56))
            scaleType = ImageView.ScaleType.CENTER_CROP
            shapeAppearanceModel = ShapeAppearanceModel.builder()
                .setAllCornerSizes(dp(28).toFloat())
                .build()
            val bitmap = BitmapFactory.decodeFile(entry.imagePath)
            if (bitmap != null) setImageBitmap(bitmap) else setImageResource(R.drawable.ic_leaf_logo)
        }
        val dateText = TextView(this).apply {
            text = dateFormat.format(java.util.Date(entry.timestamp))
            setTextColor(resources.getColor(R.color.garden_date_text, theme))
            textSize = 14f
            typeface = android.graphics.Typeface.create(android.graphics.Typeface.SERIF, android.graphics.Typeface.BOLD)
            val params = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            params.marginStart = dp(12)
            params.marginEnd = dp(8)
            layoutParams = params
        }
        val statusPill = TextView(this).apply {
            text = if (entry.isHealthy) "Healthy" else "Disease"
            setTextColor(if (entry.isHealthy) android.graphics.Color.WHITE else resources.getColor(R.color.status_disease_text, theme))
            textSize = 13f
            typeface = android.graphics.Typeface.create(android.graphics.Typeface.SERIF, android.graphics.Typeface.BOLD)
            setBackgroundResource(if (entry.isHealthy) R.drawable.bg_status_pill_healthy else R.drawable.bg_status_pill_disease)
            setPadding(dp(14), dp(6), dp(14), dp(6))
        }
        topRow.addView(thumb)
        topRow.addView(dateText)
        topRow.addView(statusPill)
        content.addView(topRow)

        // --- Row 2: tappable summary/condition line -> full details ---
        val summaryRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
            val params = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            params.topMargin = dp(14)
            layoutParams = params
            isClickable = true
            isFocusable = true
            setOnClickListener { openDetails() }
        }
        val summaryText = TextView(this).apply {
            setTextColor(android.graphics.Color.parseColor("#222222"))
            textSize = 15f
            setLineSpacing(dp(3).toFloat(), 1f)
            typeface = android.graphics.Typeface.create(android.graphics.Typeface.SERIF, android.graphics.Typeface.NORMAL)
            text = if (entry.isHealthy) {
                val bold = android.text.SpannableStringBuilder()
                bold.append("Summary: \u2705\n")
                val start = bold.length
                bold.append("Healthy Leaf - No action needed")
                bold.setSpan(
                    android.text.style.StyleSpan(android.graphics.Typeface.BOLD),
                    start, bold.length, android.text.Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
                )
                bold
            } else {
                val condition = details.mapIndexed { index, d ->
                    val pct = entry.confidences.getOrNull(index)
                    if (pct != null) "${d.displayName} (${String.format(Locale.US, "%.1f", pct * 100f)}%)" else d.displayName
                }.joinToString(", ")
                "Condition: $condition"
            }
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val actionLabel = TextView(this).apply {
            text = if (entry.isHealthy) "" else "View Details"
            setTextColor(resources.getColor(R.color.leaf_green_dark, theme))
            textSize = 13f
            typeface = android.graphics.Typeface.create(android.graphics.Typeface.SERIF, android.graphics.Typeface.BOLD)
            val params = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            params.marginEnd = dp(4)
            layoutParams = params
        }
        val chevron = ImageView(this).apply {
            setImageResource(R.drawable.ic_chevron_down)
            rotation = -90f
            setColorFilter(android.graphics.Color.parseColor("#222222"))
            layoutParams = LinearLayout.LayoutParams(dp(18), dp(18))
        }
        summaryRow.addView(summaryText)
        summaryRow.addView(actionLabel)
        summaryRow.addView(chevron)
        content.addView(summaryRow)

        // --- Confidence banner (disease results only) ---
        if (!entry.isHealthy) {
            val banner = TextView(this).apply {
                text = details.mapIndexed { index, d ->
                    val pct = entry.confidences.getOrNull(index)
                    if (pct != null) "${d.displayName} - ${String.format(Locale.US, "%.1f", pct * 100f)}% confidence" else d.displayName
                }.joinToString("\n")
                setTextColor(android.graphics.Color.parseColor("#B3261E"))
                textSize = 13f
                gravity = android.view.Gravity.CENTER
                setBackgroundResource(R.drawable.bg_disease_name_chip)
                setPadding(dp(12), dp(10), dp(12), dp(10))
                val params = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                params.topMargin = dp(12)
                layoutParams = params
            }
            content.addView(banner)
        }

        // --- Divider ---
        content.addView(View(this).apply {
            setBackgroundColor(resources.getColor(R.color.garden_divider, theme))
            val params = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(1))
            params.topMargin = dp(16)
            params.bottomMargin = dp(14)
            layoutParams = params
        })

        // --- Row 3: Scan Again / Delete ---
        val bottomRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
        }
        // A plain TextView + bg_outline_button (not a MaterialButton) --
        // matches how the scanner screen's own outline buttons (e.g. the
        // Treatment/Recommendations tabs) are built elsewhere in this file,
        // since MaterialButton manages its own background internally and
        // ignores a plain background drawable assigned to it in code.
        val scanAgainButton = TextView(this).apply {
            text = "Scan Again"
            gravity = android.view.Gravity.CENTER
            setTextColor(resources.getColor(R.color.leaf_green, theme))
            textSize = 13f
            typeface = android.graphics.Typeface.create(android.graphics.Typeface.SERIF, android.graphics.Typeface.BOLD)
            setBackgroundResource(R.drawable.bg_outline_button)
            setPadding(dp(20), dp(9), dp(20), dp(9))
            isClickable = true
            isFocusable = true
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            setOnClickListener { hideSection(); resetScannerForNewScan() }
        }
        val spacer = View(this).apply {
            layoutParams = LinearLayout.LayoutParams(0, 0, 1f)
        }
        val deleteRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
            isClickable = true
            isFocusable = true
            setPadding(dp(8), dp(8), dp(4), dp(8))
            setOnClickListener { deleteGardenEntry(raw, entry) }
        }
        val deleteLabel = TextView(this).apply {
            text = "Delete"
            setTextColor(resources.getColor(R.color.garden_delete_red, theme))
            textSize = 14f
            typeface = android.graphics.Typeface.create(android.graphics.Typeface.SERIF, android.graphics.Typeface.BOLD)
        }
        val deleteIcon = ImageView(this).apply {
            setImageResource(R.drawable.ic_delete)
            setColorFilter(resources.getColor(R.color.garden_delete_red, theme))
            layoutParams = LinearLayout.LayoutParams(dp(20), dp(20)).apply { marginStart = dp(6) }
        }
        deleteRow.addView(deleteLabel)
        deleteRow.addView(deleteIcon)
        bottomRow.addView(scanAgainButton)
        bottomRow.addView(spacer)
        bottomRow.addView(deleteRow)
        content.addView(bottomRow)

        card.addView(content)
        return card
    }

    /** Removes one saved scan (its SharedPreferences entry and its copied
     *  image file), then re-renders My Garden without it. */
    private fun deleteGardenEntry(raw: String, entry: GardenEntry) {
        val existing = (collectionPrefs.getStringSet(collectionKey, emptySet()) ?: emptySet()).toMutableSet()
        existing.remove(raw)
        collectionPrefs.edit().putStringSet(collectionKey, existing).apply()
        File(entry.imagePath).let { if (it.exists()) it.delete() }
        buildGardenCards()
        Toast.makeText(this, "Removed from My Garden.", Toast.LENGTH_SHORT).show()
    }

    /** Every info section (App Guide, My Garden, About, LGU Connect) is a
     *  title + close button, then a stack of individually shadow-boxed
     *  cards -- not one long block of text -- matching the reference
     *  About/LGU screens, then the single bottom action button. */
    private fun showSection(
        title: String,
        content: List<SectionBlock>,
        actionText: String,
        action: (() -> Unit)? = null
    ) {
        binding.sectionTitle.text = title
        binding.sectionActionButton.text = actionText
        buildSectionCards(content)
        binding.sectionPanel.visibility = android.view.View.VISIBLE
        // The capture button floats above everything (bringToFront + higher
        // elevation than sectionPanel), so it would otherwise sit on top of
        // and block the bottom of My Garden/Discover/LGU Connect content.
        // It isn't needed while a section is open anyway (tap the action
        // button or the X to get back to scanning).
        binding.captureButtonRing.visibility = android.view.View.GONE
        binding.sectionActionButton.setOnClickListener {
            if (action != null) action() else hideSection()
        }
    }

    /** Renders each [SectionBlock] as its own white shadow card (or, for a
     *  [SectionBlock.PlainLabel], a small unboxed caption above the next
     *  card) inside sectionCardsContainer. */
    private fun buildSectionCards(blocks: List<SectionBlock>) {
        val container = binding.sectionCardsContainer
        container.removeAllViews()

        val density = resources.displayMetrics.density
        fun dp(value: Int) = (value * density).toInt()

        blocks.forEach { block ->
            when (block) {
                is SectionBlock.PlainLabel -> {
                    val label = TextView(this).apply {
                        text = block.text
                        setTextColor(resources.getColor(R.color.card_label_green, theme))
                        textSize = 14f
                        typeface = android.graphics.Typeface.create(android.graphics.Typeface.SERIF, android.graphics.Typeface.BOLD)
                    }
                    val params = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                    )
                    params.bottomMargin = dp(8)
                    container.addView(label, params)
                }
                is SectionBlock.Card -> {
                    val card = LinearLayout(this).apply {
                        orientation = LinearLayout.VERTICAL
                        setBackgroundResource(R.drawable.bg_shadow_card)
                        elevation = dp(3).toFloat()
                        setPadding(dp(18), dp(16), dp(18), dp(16))
                    }
                    if (block.header != null) {
                        val headerView = TextView(this).apply {
                            text = block.header
                            setTextColor(resources.getColor(R.color.card_label_green, theme))
                            textSize = 15f
                            typeface = android.graphics.Typeface.create(android.graphics.Typeface.SERIF, android.graphics.Typeface.BOLD)
                        }
                        val headerParams = LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.MATCH_PARENT,
                            LinearLayout.LayoutParams.WRAP_CONTENT
                        )
                        headerParams.bottomMargin = dp(8)
                        card.addView(headerView, headerParams)
                    }
                    val bodyView = TextView(this).apply {
                        text = block.body
                        setTextColor(android.graphics.Color.parseColor("#222222"))
                        textSize = 14f
                        setLineSpacing(dp(4).toFloat(), 1f)
                        typeface = android.graphics.Typeface.create(android.graphics.Typeface.SERIF, android.graphics.Typeface.NORMAL)
                    }
                    card.addView(
                        bodyView,
                        LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.MATCH_PARENT,
                            LinearLayout.LayoutParams.WRAP_CONTENT
                        )
                    )
                    val cardParams = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                    )
                    cardParams.bottomMargin = dp(14)
                    container.addView(card, cardParams)
                }
            }
        }
    }

    private fun resetScannerForNewScan() {
        hideSection()
        hideResultSheet()
        // Live analysis is free to drive the overlay again.
        showingCapturedResult = false
        // Back to the live camera: drop the frozen shot from the last scan.
        binding.capturedFreezeFrame.visibility = View.GONE
        binding.capturedFreezeFrame.setImageDrawable(null)
        freezeFrameBitmap?.recycle()
        freezeFrameBitmap = null
        lastResultPath = ""
        lastDiseaseNames = arrayListOf()
        lastDiseaseConfidences = floatArrayOf()
        lastHealthyConfidence = 0f
        lastDetectedSpokenText = ""
        binding.captureButton.isEnabled = true
        binding.progressBar.visibility = View.GONE
        // Top toolbar (logo/title, flash, settings) and camera-overlay status
        // text both come back once there's no result showing.
        binding.topBar.visibility = View.VISIBLE
        binding.detectionTitle.visibility = View.VISIBLE
        binding.detectionConfidence.visibility = View.VISIBLE
        binding.detectionHealth.visibility = View.VISIBLE
        applyStatusColor(leafPresent = false, hasDisease = false)
        binding.detectionTitle.text = "NO BANANA LEAF DETECTED"
        binding.detectionConfidence.text = "Ready to scan"
        binding.detectionHealth.text = "Center a real banana leaf inside the frame"
        binding.addCollectionButton.text = "ADD TO COLLECTION"
    }

    private fun hideSection() {
        binding.sectionPanel.visibility = android.view.View.GONE
        // Bring the capture button back, unless a scan result sheet is the
        // one currently up (that already hides it on its own).
        if (binding.infoPanel.visibility != android.view.View.VISIBLE) {
            binding.captureButtonRing.visibility = android.view.View.VISIBLE
        }
        binding.sectionActionButton.setOnClickListener { hideSection() }
    }

    /** Result sheet is controlled by taps only; no swipe gesture is required. */
    private fun setupResultSheetClicks() {
        binding.resultHandle.setOnClickListener {
            animateResultSheet(!resultSheetExpanded)
        }

        // When a result is showing, tapping the exposed camera area dismisses
        // the result and immediately prepares the scanner for a new scan.
        binding.scanFrame.setOnClickListener {
            if (binding.infoPanel.visibility == View.VISIBLE) {
                resetScannerForNewScan()
            }
        }
    }

    /** Collapsed ("peek") state shows just enough to see the handle,
     *  title/speaker card, subtitle, and the Disease/Treatment/Recommendations
     *  toolbar -- sized to that content only (no forced minimum screen
     *  fraction), so the peek sheet sits low, hugs its content, and doesn't
     *  leave dead white space below the toolbar. The rest of the result
     *  stays hidden (and more of the camera visible above it) until the user
     *  actually taps the handle, a tab, or the speaker icon to open it fully. */
    private fun collapsedSheetTranslation(): Float {
        val density = resources.displayMetrics.density
        val handleH = binding.resultHandle.height
        val titleCardH = binding.infoTitleCard.height
        val summaryH = binding.resultSummary.height
        val toolbarH = binding.resultToolbar.height
        val minContentPeekPx = handleH + titleCardH + summaryH + toolbarH + (24f * density)
        val peekPx = if (handleH > 0 && titleCardH > 0) {
            minContentPeekPx
        } else {
            220f * density
        }
        return (binding.infoPanel.height - peekPx).coerceAtLeast(0f)
    }

    /** Disease/Treatment/Recommendations tabs and their content, plus the
     *  action buttons, only appear once the result sheet is tapped open. */
    private fun animateResultSheet(expand: Boolean) {
        if (binding.infoPanel.height == 0) {
            binding.infoPanel.post { animateResultSheet(expand) }
            return
        }
        resultSheetExpanded = expand
        binding.resultDetailContainer.visibility = if (expand) View.VISIBLE else View.GONE
        val target = if (expand) 0f else collapsedSheetTranslation()
        binding.infoPanel.animate()
            .translationY(target)
            .setDuration(180L)
            .start()
        binding.resultHandle.contentDescription =
            if (expand) "Collapse scan result" else "Open scan result"
        // Top toolbar (logo/title, flash, settings) is hidden ONLY once the
        // result sheet is actually tapped open. In the collapsed "peek" state
        // (TAP TO VIEW RESULT) the top bar stays visible, matching the
        // reference screen. It reappears the moment the sheet is collapsed
        // again, without needing a new scan.
        binding.topBar.visibility = if (expand) View.GONE else View.VISIBLE
        keepCaptureButtonOnTop()
    }

    private fun showResultSheet() {
        binding.infoPanel.visibility = View.VISIBLE
        binding.infoPanel.alpha = 1f
        binding.resultDetailContainer.visibility = View.GONE
        // The capture button is only for taking a new photo, which isn't the
        // point once a result is showing -- tapping the exposed camera area
        // (scanFrame) already resets for a new scan, so the round button is
        // hidden while a result is up, matching the reference screen.
        binding.captureButtonRing.visibility = View.GONE
        binding.infoPanel.post {
            binding.infoPanel.translationY = collapsedSheetTranslation()
            resultSheetExpanded = false
            binding.resultHandle.contentDescription = "Open scan result"
            keepCaptureButtonOnTop()
        }
    }

    private fun hideResultSheet() {
        binding.infoPanel.animate().cancel()
        binding.infoPanel.visibility = View.GONE
        binding.infoPanel.translationY = 0f
        binding.resultDetailContainer.visibility = View.GONE
        resultSheetExpanded = false
        // Bring the capture button back now that there's no result covering it.
        binding.captureButtonRing.visibility = View.VISIBLE
    }

    /**
     * Sets which tab's content is shown (section visibility + tab highlight
     * colors) only -- it does NOT expand the result sheet and does NOT speak.
     * This is the piece that's safe to call automatically right after a scan
     * finishes, so the sheet can start in its collapsed "peek" state (half
     * the screen, "TAP TO VIEW RESULT") and stay silent until the user
     * actually taps something.
     */
    private fun applyResultTabContent(tab: Int) {
        currentResultTab = tab
        binding.diseaseSection.visibility = if (tab == 0) View.VISIBLE else View.GONE
        binding.treatmentSection.visibility = if (tab == 1) View.VISIBLE else View.GONE
        binding.recommendationSection.visibility = if (tab == 2) View.VISIBLE else View.GONE

        binding.tabDisease.setBackgroundResource(
            if (tab == 0) R.drawable.bg_green_button else R.drawable.bg_outline_button
        )
        binding.tabTreatment.setBackgroundResource(
            if (tab == 1) R.drawable.bg_green_button else R.drawable.bg_outline_button
        )
        binding.tabRecommendations.setBackgroundResource(
            if (tab == 2) R.drawable.bg_green_button else R.drawable.bg_outline_button
        )

        binding.tabDisease.setTextColor(
            getColor(if (tab == 0) R.color.white else R.color.leaf_green_dark)
        )
        binding.tabTreatment.setTextColor(
            getColor(if (tab == 1) R.color.white else R.color.leaf_green_dark)
        )
        binding.tabRecommendations.setTextColor(
            getColor(if (tab == 2) R.color.white else R.color.leaf_green_dark)
        )
    }

    /**
     * Tapping Disease/Treatment/Recommendations (visible up front, in the
     * collapsed "peek" state) both opens that tab's content and immediately
     * reads it aloud -- the user doesn't need to also tap the speaker icon.
     * Only reached from an explicit user tap on a tab (or the speaker
     * button, which calls speakCurrentResult() directly); the initial tab
     * state right after a scan uses applyResultTabContent() instead, so
     * nothing expands or speaks until the user taps.
     */
    private fun selectResultTab(tab: Int) {
        applyResultTabContent(tab)

        // Expand the sheet so the newly selected tab's content is actually
        // visible (the toolbar itself is already visible while collapsed).
        if (!resultSheetExpanded) {
            animateResultSheet(true)
        }
        binding.infoPanel.smoothScrollTo(0, 0)

        // Auto-speak the tab that was just opened.
        speakCurrentResult()
    }

    private fun showScanResultPanel(
        diseaseNames: List<String>,
        diseaseConfidences: FloatArray,
        healthyConfidence: Float
    ) {
        val isHealthy = diseaseNames.isEmpty()

        // Result tabs now show only the single top/highest-confidence item per
        // category -- the full symptom list, full treatment steps, and full
        // recommendation list are reserved for VIEW MORE DETAILS (DetailsActivity).
        // diseaseNames/diseaseConfidences already arrive sorted descending by
        // confidence (see the capture pipeline), so index 0 is always the top result.
        val topDiseaseName = diseaseNames.firstOrNull()
        lastTopResultKey = if (isHealthy) "Healthy" else topDiseaseName!!

        val diseaseText = if (isHealthy) {
            DiseaseInfo.get("Healthy").overview
        } else {
            DiseaseInfo.get(topDiseaseName!!).overview
        }

        val treatmentText = if (isHealthy) {
            DiseaseInfo.get("Healthy").treatment.firstOrNull().orEmpty()
        } else {
            "• " + DiseaseInfo.get(topDiseaseName!!).treatment.firstOrNull().orEmpty()
        }

        val recommendationText = if (isHealthy) {
            DiseaseInfo.get("Healthy").recommendations.firstOrNull().orEmpty()
        } else {
            DiseaseInfo.get(topDiseaseName!!).recommendations.firstOrNull().orEmpty()
        }

        // Final decision mode:
        // 0 diseases = HEALTHY, 1 disease = SINGLE LABEL, 2-3 diseases = MULTI LABEL.
        // The single-label case is intentionally supported by the same three
        // independently trained disease models: when exactly one disease passes
        // its calibrated threshold, that disease is returned as the single label.
        val decisionMode = when {
            diseaseNames.isEmpty() -> "HEALTHY"
            diseaseNames.size == 1 -> "SINGLE LABEL"
            else -> "MULTI LABEL"
        }

        binding.infoTitle.text = when (decisionMode) {
            "HEALTHY" -> "Healthy Banana Leaf"
            "SINGLE LABEL" -> DiseaseInfo.get(diseaseNames.first()).displayName
            else -> diseaseNames.joinToString(" & ") { DiseaseInfo.get(it).displayName }
        }
        binding.resultSummary.text = when (decisionMode) {
            "HEALTHY" -> "HEALTHY • Leaf confidence: ${(healthyConfidence * 100f).formatPercent()}"
            "SINGLE LABEL" -> {
                val name = DiseaseInfo.get(diseaseNames.first()).displayName
                val confidence = diseaseConfidences.firstOrNull() ?: 0f
                val pct = (confidence * 100f).formatPercent()
                if (confidence < LOW_CONFIDENCE_THRESHOLD) {
                    "UNCERTAIN • $name • $pct confidence — this is close to the detection threshold, please retake the photo"
                } else {
                    "SINGLE LABEL • $name • $pct confidence"
                }
            }
            else -> "MULTI LABEL • ${diseaseNames.size} possible diseases detected"
        }
        binding.diseaseResultText.text = diseaseText
        binding.treatmentResultText.text = treatmentText
        binding.recommendationResultText.text = "• $recommendationText"
        // Chips also show the single top disease only, matching the tabs above.
        val topChipNames = if (isHealthy) diseaseNames else diseaseNames.take(1)
        val topChipConfidences = if (isHealthy) diseaseConfidences else diseaseConfidences.take(1).toFloatArray()
        buildDiseaseNameChips(topChipNames, topChipConfidences, isHealthy)

        // Kept only for the speaker button's read-aloud text (no longer shown
        // as its own box -- the title card + subtitle above cover that now).
        lastDetectedSpokenText = when (decisionMode) {
            "HEALTHY" -> "Detected: Healthy Leaf"
            "SINGLE LABEL" -> "Detected: ${DiseaseInfo.get(diseaseNames.first()).displayName}"
            else -> "Detected: ${diseaseNames.joinToString(", ") { DiseaseInfo.get(it).displayName }}"
        }

        // A result is now on screen, so the camera-overlay scanning text
        // ("BANANA LEAF DETECTED" etc.) is no longer needed.
        binding.detectionTitle.visibility = View.GONE
        binding.detectionConfidence.visibility = View.GONE
        binding.detectionHealth.visibility = View.GONE

        // Result mode: the top toolbar (logo/title, flash, settings) stays
        // VISIBLE here -- the sheet opens in its collapsed "peek" state
        // (TAP TO VIEW RESULT), same as the reference screen. It is hidden
        // only once the sheet is actually tapped open (see animateResultSheet),
        // and comes back automatically when collapsed again or on New Scan/Home.
        //
        // Only the tab CONTENT is set up here (applyResultTabContent), not
        // selectResultTab -- that would also expand the sheet and speak the
        // result immediately. The sheet should stay collapsed (peek/half the
        // screen) and silent until the user actually taps the handle, a tab,
        // or the speaker button.
        showResultSheet()
        binding.infoPanel.smoothScrollTo(0, 0)
        applyResultTabContent(0)
    }

    /**
     * Renders each identified disease name as its own bordered "chip" box so it
     * is immediately identifiable, separate from the descriptive paragraph text.
     */
    private fun buildDiseaseNameChips(
        diseaseNames: List<String>,
        diseaseConfidences: FloatArray,
        isHealthy: Boolean
    ) {
        val container = binding.diseaseNameChips
        container.removeAllViews()

        val density = resources.displayMetrics.density
        fun dp(value: Int) = (value * density).toInt()

        fun addChip(label: String, healthy: Boolean) {
            val chip = TextView(this).apply {
                text = label
                setTextColor(if (healthy) resources.getColor(R.color.leaf_green_dark, theme) else android.graphics.Color.parseColor("#B3261E"))
                textSize = 16f
                typeface = android.graphics.Typeface.create(android.graphics.Typeface.SERIF, android.graphics.Typeface.BOLD)
                setPadding(dp(14), dp(8), dp(14), dp(8))
                setBackgroundResource(
                    if (healthy) R.drawable.bg_disease_name_chip_healthy else R.drawable.bg_disease_name_chip
                )
            }
            val params = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            params.bottomMargin = dp(8)
            container.addView(chip, params)
        }

        if (isHealthy) {
            addChip("✓ Healthy Leaf", healthy = true)
        } else {
            diseaseNames.forEachIndexed { index, name ->
                val details = DiseaseInfo.get(name)
                val confidence = (diseaseConfidences.getOrElse(index) { 0f } * 100f).formatPercent()
                addChip("${details.displayName} • $confidence", healthy = false)
            }
        }
    }

    private fun Float.formatPercent(): String = String.format(java.util.Locale.US, "%.1f%%", this)

    private fun startCamera() {
        val cameraProviderFuture = ProcessCameraProvider.getInstance(this)
        cameraProviderFuture.addListener({
            val cameraProvider = cameraProviderFuture.get()

            val preview = Preview.Builder().build().also {
                it.setSurfaceProvider(binding.viewFinder.surfaceProvider)
            }

            imageCapture = ImageCapture.Builder()
                .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
                .build()

            // Continuous "leaf in focus" preview: STRATEGY_KEEP_ONLY_LATEST
            // means CameraX itself only ever hands us the newest frame,
            // never a queue of stale ones, which pairs with the
            // liveAnalysisBusy guard in analyzeLiveFrame() to keep this
            // fully self-throttled to real device speed.
            val imageAnalysis = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build()
                .also { it.setAnalyzer(cameraExecutor, ::analyzeLiveFrame) }

            val cameraSelector = CameraSelector.DEFAULT_BACK_CAMERA

            try {
                cameraProvider.unbindAll()
                camera = cameraProvider.bindToLifecycle(
                    this, cameraSelector, preview, imageCapture, imageAnalysis
                )
                setupFlashButton()
            } catch (e: Exception) {
                Toast.makeText(this, getString(R.string.camera_start_failed, e.message), Toast.LENGTH_LONG).show()
            }
        }, ContextCompat.getMainExecutor(this))
    }

    /**
     * Enables the flash toggle button only if the device actually has a flash unit,
     * and wires up the click listener to turn the torch on/off.
     */
    private fun setupFlashButton() {
        val currentCamera = camera ?: return
        val hasFlash = currentCamera.cameraInfo.hasFlashUnit()

        if (!hasFlash) {
            binding.flashButton.visibility = android.view.View.GONE
            binding.flashButton.isEnabled = false
            return
        }

        binding.flashButton.visibility = android.view.View.VISIBLE
        binding.flashButton.isEnabled = true
        isFlashOn = false
        updateTorchButton(false)

        // Keep the icon synchronized with the real CameraX torch state.
        currentCamera.cameraInfo.torchState.observe(this) { state ->
            val on = state == TorchState.ON
            isFlashOn = on
            updateTorchButton(on)
        }

        binding.flashButton.setOnClickListener {
            // Fetch the live camera reference at tap time instead of the one
            // captured when setupFlashButton() first ran -- startCamera() can
            // rebind and replace `camera`, and using a stale reference is why
            // taps could silently do nothing after the first one.
            val currentCam = camera
            if (currentCam == null) {
                Toast.makeText(this, "Camera isn't ready yet.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val nextState = !isFlashOn

            // Update the icon/state immediately on every tap. Previously the
            // button disabled itself and waited for the torch future to
            // complete before re-enabling -- if that future was ever slow or
            // never resolved (seen on some devices/emulators), the button
            // stayed disabled forever and every further tap did nothing at
            // all, which matches "tapped it three times, nothing happened".
            isFlashOn = nextState
            updateTorchButton(nextState)

            try {
                val future = currentCam.cameraControl.enableTorch(nextState)
                future.addListener({
                    try {
                        // future.get() throws if the torch request actually
                        // failed on-device; on success the torchState
                        // observer above keeps the icon in sync anyway.
                        future.get()
                    } catch (e: Exception) {
                        isFlashOn = false
                        updateTorchButton(false)
                        Toast.makeText(
                            this,
                            "Flash isn't available on this device right now.",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }, ContextCompat.getMainExecutor(this))
            } catch (e: Exception) {
                // Defensive: some OEM camera stacks throw synchronously instead
                // of failing the future.
                isFlashOn = false
                updateTorchButton(false)
                Toast.makeText(
                    this,
                    "Flash isn't available on this device right now.",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }

    /**
     * Re-asserts the draw/touch order of the controls that sit visually above
     * the result sheet: the capture button ring AND the top toolbar (flash +
     * settings buttons).
     *
     * infoPanel is added to the layout AFTER topBar, and once it's visible it
     * stretches from the very top of the screen down to bottomNav -- the same
     * vertical band as topBar. topBar only stays visible on top because of its
     * higher android:elevation, but elevation alone does not reliably reorder
     * TOUCH dispatch on every Android version: on some OS versions touch still
     * follows child order, not Z/elevation. That let the invisible-but-present
     * resultHandle (part of infoPanel, itself clickable so it can expand the
     * sheet) silently swallow taps aimed at the flash/settings buttons drawn
     * above it -- which is exactly why the flashlight button stopped
     * responding once a scan result was showing.
     *
     * bringToFront() moves a view to the end of its parent's actual child
     * list, which fixes both drawing AND touch dispatch order everywhere,
     * regardless of elevation/Android version quirks.
     *
     * bottomNav is included for the same reason: infoPanel is a tall view
     * (top of screen down to bottomNav's top) that gets slid down with
     * translationY for its collapsed "peek" state. That slide is a render
     * transform only -- it doesn't change infoPanel's layout bounds -- so
     * infoPanel's own bottom edge (and its opaque white background) ends up
     * drawn past bottomNav's top, covering the nav bar with blank white
     * space instead of leaving it visible. bringToFront() keeps bottomNav
     * drawn (and tappable) above infoPanel at all times.
     */
    private fun keepCaptureButtonOnTop() {
        binding.topBar.bringToFront()
        binding.captureButtonRing.bringToFront()
        binding.bottomNav.bringToFront()
        (binding.root as? View)?.requestLayout()
        binding.root.invalidate()
    }

    private fun updateTorchButton(torchOn: Boolean) {
        binding.flashButton.setImageResource(
            if (torchOn) R.drawable.ic_flash_on else R.drawable.ic_flash_off
        )
        binding.flashButton.contentDescription =
            getString(if (torchOn) R.string.flash_on else R.string.flash_off)
    }

    private fun capturePhoto() {
        val capture = imageCapture ?: return
        // Freeze the live-preview overlay right away -- the shutter tap is
        // what "locks in" the diagnosis, matching "Tap shutter to diagnose".
        showingCapturedResult = true
        hideResultSheet()
        binding.sectionPanel.visibility = View.GONE
        binding.captureButton.isEnabled = false
        // Drop any freeze frame from the previous scan and show the live
        // camera again while this new photo is taken.
        binding.capturedFreezeFrame.visibility = View.GONE
        binding.capturedFreezeFrame.setImageDrawable(null)
        freezeFrameBitmap?.recycle()
        freezeFrameBitmap = null
        binding.progressBar.visibility = android.view.View.VISIBLE
        // Bring the top toolbar and camera-overlay status text back for the
        // new scan, in case they were hidden while the previous result was showing.
        binding.topBar.visibility = View.VISIBLE
        binding.detectionTitle.visibility = View.VISIBLE
        binding.detectionConfidence.visibility = View.VISIBLE
        binding.detectionHealth.visibility = View.VISIBLE
        binding.detectionTitle.text = "ANALYZING BANANA LEAF"
        binding.detectionConfidence.text = "Please wait..."
        binding.detectionHealth.text = "Running offline leaf analysis models"
        // Clear the previous scan's "SAVED TO COLLECTION" state so it doesn't
        // linger and look like it belongs to the new leaf being scanned now.
        binding.addCollectionButton.text = "ADD TO COLLECTION"
        // Clear the previous scan's stored result too, so "VIEW MORE DETAILS"
        // can't show old data while the new photo is still being analyzed.
        lastResultPath = ""
        lastDiseaseNames = arrayListOf()
        lastDiseaseConfidences = floatArrayOf()
        lastHealthyConfidence = 0f

        capture.takePicture(
            ContextCompat.getMainExecutor(this),
            object : ImageCapture.OnImageCapturedCallback() {
                override fun onCaptureSuccess(image: ImageProxy) {
                    val bitmap = try {
                        imageProxyToBitmap(image)
                    } finally {
                        image.close()
                    }

                    if (bitmap == null) {
                        binding.captureButton.isEnabled = true
                        binding.progressBar.visibility = View.GONE
                        binding.detectionTitle.text = "IMAGE PROCESSING FAILED"
                        binding.detectionConfidence.text = "Please try again"
                        binding.detectionHealth.text = "The captured image could not be decoded"
                        return
                    }

                    // Freeze the shot on screen (a separate copy, so recycling
                    // the working bitmap in runInference() can't affect it).
                    val freezeCopy = bitmap.copy(bitmap.config ?: Bitmap.Config.ARGB_8888, false)
                    freezeFrameBitmap?.recycle()
                    freezeFrameBitmap = freezeCopy
                    binding.capturedFreezeFrame.setImageBitmap(freezeCopy)
                    binding.capturedFreezeFrame.visibility = View.VISIBLE

                    runInference(bitmap)
                }

                override fun onError(exception: ImageCaptureException) {
                    binding.captureButton.isEnabled = true
                    binding.progressBar.visibility = android.view.View.GONE
                    Toast.makeText(this@MainActivity, getString(R.string.capture_failed, exception.message), Toast.LENGTH_LONG).show()
                }
            }
        )
    }

    /**
     * ImageCapture is configured to return JPEG frames, so plane 0 contains the
     * encoded JPEG bytes. Decode it defensively and apply CameraX rotation.
     */
    private fun imageProxyToBitmap(image: ImageProxy): Bitmap? {
        val plane = image.planes.firstOrNull() ?: return null
        val buffer = plane.buffer
        val bytes = ByteArray(buffer.remaining())
        buffer.get(bytes)
        val bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: return null

        val rotation = image.imageInfo.rotationDegrees
        if (rotation == 0) return bitmap

        val matrix = Matrix().apply { postRotate(rotation.toFloat()) }
        val rotated = Bitmap.createBitmap(
            bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true
        )
        if (rotated !== bitmap) bitmap.recycle()
        return rotated
    }

    /**
     * Runs the full offline pipeline: OpenCV feature extraction -> leaf gate
     * -> three independent disease checks -> scaling -> RF classification.
     * Exact inference order used by the supplied training notebook:
     * image -> 33 handcrafted features -> one StandardScaler -> IsLeaf gate
     * -> three independent disease heads. Zero disease heads means Healthy;
     * one means SINGLE LABEL; two or three means MULTI LABEL.
     */
    /**
     * Shows "Inference: X ms | FPS: Y | RAM: Z MB" over the camera preview,
     * same style as the debug overlay in the reference sample. Must be called
     * on the UI thread.
     */
    private fun updateInferenceStats(startMs: Long) {
        val elapsedMs = (SystemClock.elapsedRealtime() - startMs).coerceAtLeast(1L)
        val fps = 1000f / elapsedMs
        val runtime = Runtime.getRuntime()
        val usedMb = (runtime.totalMemory() - runtime.freeMemory()) / (1024f * 1024f)
        binding.inferenceStatsBar.text = String.format(
            java.util.Locale.US, "Inference: %.2f ms | FPS: %.1f | RAM: %.0f MB", elapsedMs.toFloat(), fps, usedMb
        )
        binding.inferenceStatsBar.visibility = View.VISIBLE
    }

    /** Pure result of [computeDiagnosis]: no UI, no file I/O, just what the
     *  four models said about one bitmap. */
    private data class Diagnosis(
        val leafPresent: Boolean,
        val leafProb: Float,
        val vegRatio: Float,
        val diseaseNames: List<String>,
        val diseaseConfidences: FloatArray,
        val healthyConfidence: Float
    )

    /**
     * Runs the full offline pipeline: OpenCV feature extraction -> leaf gate
     * -> three independent disease checks -> scaling -> RF classification.
     * Exact inference order used by the supplied training notebook:
     * image -> 33 handcrafted features -> one StandardScaler -> IsLeaf gate
     * -> three independent disease heads. Zero disease heads means Healthy;
     * one means SINGLE LABEL; two or three means MULTI LABEL.
     *
     * This is the ONE place that logic lives -- both a real shutter-
     * triggered scan (runInference) and every throttled live-preview frame
     * (analyzeLiveFrame) call this same function, so the two can never
     * drift out of sync with each other. Must be called off the main
     * thread; does its own OpenCV Mat allocation/release and touches no
     * views.
     */
    private fun computeDiagnosis(bitmap: Bitmap): Diagnosis {
        if (bitmap.isRecycled || bitmap.width <= 0 || bitmap.height <= 0) {
            throw IllegalArgumentException("Invalid bitmap")
        }

        val bgrMat = Mat()
        Utils.bitmapToMat(bitmap, bgrMat)
        if (bgrMat.empty()) {
            bgrMat.release()
            throw IllegalArgumentException("Unable to convert image to OpenCV Mat")
        }
        Imgproc.cvtColor(bgrMat, bgrMat, Imgproc.COLOR_RGBA2BGR)

        // Current training has two feature spaces:
        // 10 features for the leaf gate and 15 for each disease head.
        val leafFeatures = ImageProcessor.leafPresenceFeatures(bgrMat)
        val leafScaled = FeatureScaler.transformLeaf(leafFeatures)
        val leafProb = leafModel.positiveProbability(leafScaled)
        bgrMat.release()

        val vegRatio = leafFeatures[0].toFloat()

        // Two independent checks must BOTH pass before we trust "this is a
        // banana leaf": the learned RF probability, and a cheap rule-based
        // vegetation-coverage floor. See VEG_RATIO_MIN_THRESHOLD above for
        // why the rule-based check exists -- it catches non-leaf objects
        // (fabric, walls, curtains, etc.) that the ML gate wasn't trained
        // to recognize, without needing new training data.
        val failsMlGate = leafProb < LEAF_PRESENT_THRESHOLD
        val failsVegFloor = vegRatio < VEG_RATIO_MIN_THRESHOLD

        if (failsMlGate || failsVegFloor) {
            // Restriction: disease analysis only runs after the leaf-presence
            // gate confirms that the frame contains a banana leaf.
            return Diagnosis(false, leafProb, vegRatio, emptyList(), floatArrayOf(), 0f)
        }

        // Disease models use the current notebook's 15-feature vector
        // and the separately fitted disease StandardScaler.
        val diseaseFeatures = run {
            // Reconstructing from the original bitmap keeps the feature
            // extraction identical to the leaf-gate path.
            val mat = Mat()
            Utils.bitmapToMat(bitmap, mat)
            Imgproc.cvtColor(mat, mat, Imgproc.COLOR_RGBA2BGR)
            val f = ImageProcessor.diseaseFeatures(mat)
            mat.release()
            f
        }
        val diseaseScaled = FeatureScaler.transformDisease(diseaseFeatures)

        val allProbs = linkedMapOf(
            "Cordana" to cordanaModel.positiveProbability(diseaseScaled),
            "Pestalotiopsis" to pestalotiopsisModel.positiveProbability(diseaseScaled),
            "Sigatoka" to sigatokaModel.positiveProbability(diseaseScaled)
        )
        val thresholds = mapOf(
            "Cordana" to CORDANA_THRESHOLD,
            "Pestalotiopsis" to PESTALOTIOPSIS_THRESHOLD,
            "Sigatoka" to SIGATOKA_THRESHOLD
        )
        val detected = allProbs
            .filter { (name, prob) -> prob >= thresholds.getValue(name) }
            .toList()
            .sortedByDescending { it.second }

        val diseaseNames = detected.map { it.first }
        val diseaseConfidences = detected.map { it.second }.toFloatArray()
        val healthyConfidence = 1f - (allProbs.values.maxOrNull() ?: 0f)

        return Diagnosis(true, leafProb, vegRatio, diseaseNames, diseaseConfidences, healthyConfidence)
    }

    /**
     * Amber/green/red for the status pill (dot, title, % badge, confidence
     * bar) and the scan-frame corner brackets, shared by both the
     * continuous live preview and the final shutter-triggered result so the
     * two always agree: red = not a banana leaf, amber = one or more
     * diseases detected (matches the amber "Disease" pill already used on
     * My Garden cards), green = healthy leaf.
     *
     * The corner brackets only ever go green/red (leaf present or not) --
     * never amber -- since their job is just to confirm "this is a banana
     * leaf", matching the reference design where a diseased leaf still gets
     * a green frame.
     *
     * [confidence] (0f-1f) fills the thin bar under the title; it defaults
     * to a full bar, appropriate for the "definitely not a leaf" case.
     */
    private fun applyStatusColor(leafPresent: Boolean, hasDisease: Boolean, confidence: Float = 1f) {
        val color = when {
            !leafPresent -> Color.parseColor("#FF5252")
            hasDisease -> Color.parseColor("#F2C230")
            else -> Color.parseColor("#32CD32")
        }
        val frameColor = if (leafPresent) Color.parseColor("#32CD32") else Color.parseColor("#FF5252")

        binding.scanFrameCorners.cornerColor = frameColor
        binding.detectionTitle.setTextColor(color)
        binding.statusDot.background?.setTint(color)

        // The % badge only makes sense once a leaf is actually present --
        // for "no leaf" / "not a leaf" states it's hidden entirely instead
        // of showing an empty or irrelevant chip.
        binding.detectionConfidence.visibility = if (leafPresent) View.VISIBLE else View.GONE
        (binding.detectionConfidence.background as? GradientDrawable)?.let { drawable ->
            val mutated = drawable.mutate() as GradientDrawable
            mutated.setStroke((1 * resources.displayMetrics.density).toInt(), color)
        }
        binding.detectionConfidence.setTextColor(color)

        binding.statusConfidenceBarFill.background?.setTint(color)
        val track = binding.statusConfidenceBarTrack
        val fill = binding.statusConfidenceBarFill
        track.post {
            val totalWidth = track.width
            if (totalWidth > 0) {
                val lp = fill.layoutParams
                lp.width = (totalWidth * confidence.coerceIn(0f, 1f)).toInt()
                fill.layoutParams = lp
            }
        }
    }

    /**
     * One line summarizing a multilabel result with EACH detected disease's
     * own confidence, e.g. "Sigatoka 83% · Cordana 61%" -- used instead of
     * a vague "MULTI LABEL • N possible diseases" count so a leaf with more
     * than one disease actually shows which ones, and how confident each
     * individual call is, in both the live preview and the final result.
     */
    private fun formatDiseaseSummary(diseaseNames: List<String>, diseaseConfidences: FloatArray): String {
        if (diseaseNames.isEmpty()) return "Healthy"
        return diseaseNames.indices.joinToString(" · ") { i ->
            val name = DiseaseInfo.get(diseaseNames[i]).displayName
            val conf = diseaseConfidences.getOrElse(i) { 0f }
            "$name ${(conf * 100f).toInt()}%"
        }
    }

    private fun runInference(bitmap: Bitmap) {
        val inferenceStartMs = SystemClock.elapsedRealtime()
        Thread {
            try {
                val diagnosis = computeDiagnosis(bitmap)

                if (!diagnosis.leafPresent) {
                    // No notification/toast is shown; the status at the top is enough.
                    if (!bitmap.isRecycled) bitmap.recycle()
                    runOnUiThread {
                        updateInferenceStats(inferenceStartMs)
                        hideResultSheet()
                        lastResultPath = ""
                        lastDiseaseNames = arrayListOf()
                        lastDiseaseConfidences = floatArrayOf()
                        lastHealthyConfidence = 0f
                        binding.captureButton.isEnabled = true
                        binding.progressBar.visibility = View.GONE
                        binding.detectionTitle.visibility = View.VISIBLE
                        binding.detectionConfidence.visibility = View.VISIBLE
                        binding.detectionHealth.visibility = View.VISIBLE
                        applyStatusColor(leafPresent = false, hasDisease = false)
                        binding.detectionTitle.text = "NO BANANA LEAF DETECTED"
                        binding.detectionConfidence.text = "Try another photo"
                        binding.detectionHealth.text = "Center a real banana leaf inside the frame"
                    }
                    return@Thread
                }

                val diseaseNames = ArrayList(diagnosis.diseaseNames)
                val diseaseConfidences = diagnosis.diseaseConfidences

                val tempFile = File(cacheDir, "captured_leaf.jpg")
                FileOutputStream(tempFile).use { out ->
                    check(bitmap.compress(Bitmap.CompressFormat.JPEG, 90, out)) {
                        "Unable to save captured image"
                    }
                }
                if (!bitmap.isRecycled) bitmap.recycle()

                runOnUiThread {
                    updateInferenceStats(inferenceStartMs)
                    binding.captureButton.isEnabled = true
                    binding.progressBar.visibility = View.GONE
                    applyStatusColor(leafPresent = true, hasDisease = diseaseNames.isNotEmpty(), confidence = diagnosis.leafProb)
                    binding.detectionTitle.text = "BANANA LEAF DETECTED"
                    binding.detectionConfidence.text = getString(
                        R.string.leaf_confidence_format, diagnosis.leafProb * 100f
                    )
                    binding.detectionHealth.text = when {
                        diseaseNames.isEmpty() -> "Healthy"
                        diseaseNames.size == 1 -> {
                            val name = DiseaseInfo.get(diseaseNames[0]).displayName
                            val conf = diseaseConfidences.firstOrNull() ?: 0f
                            if (conf < LOW_CONFIDENCE_THRESHOLD) {
                                "UNCERTAIN • $name (low confidence — retake for a clearer result)"
                            } else {
                                "SINGLE LABEL • $name (${(conf * 100f).toInt()}%)"
                            }
                        }
                        else -> "MULTI LABEL • " + formatDiseaseSummary(diseaseNames, diseaseConfidences)
                    }
                    lastResultPath = tempFile.absolutePath
                    lastDiseaseNames = diseaseNames
                    lastDiseaseConfidences = diseaseConfidences
                    lastHealthyConfidence = diagnosis.healthyConfidence

                    // If a disease is detected, turn the torch off immediately.
                    // If the result is healthy, keep the user's torch state unchanged
                    // so they can continue scanning under the same lighting.
                    if (diseaseNames.isNotEmpty() && isFlashOn) {
                        camera?.cameraControl?.enableTorch(false)
                        isFlashOn = false
                        updateTorchButton(false)
                    }

                    // Result toolbar appears only after a successful scan and
                    // contains Disease / Treatment / Recommendations tabs.
                    showScanResultPanel(diseaseNames, diseaseConfidences, diagnosis.healthyConfidence)
                }
            } catch (e: Exception) {
                runOnUiThread {
                    hideResultSheet()
                    binding.captureButton.isEnabled = true
                    binding.progressBar.visibility = View.GONE
                    binding.detectionTitle.text = "SCAN FAILED"
                    binding.detectionConfidence.text = "Please try again"
                    binding.detectionHealth.text = "Make sure the leaf is well lit and centered"
                    Toast.makeText(this, getString(R.string.processing_failed, e.message), Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    /**
     * Called by CameraX on [cameraExecutor] for (almost) every preview
     * frame. Drops the frame immediately -- instead of queueing it -- if a
     * captured result is currently on screen, or if the previous live frame
     * is still being processed; that self-throttles the live update rate to
     * this device's real speed rather than piling up a backlog. Reuses
     * [computeDiagnosis], the exact same pipeline a real shutter-triggered
     * scan uses, but only ever updates the live status pill / scan-frame
     * color -- it never writes a file and never touches lastResultPath or
     * My Garden.
     */
    private fun analyzeLiveFrame(image: ImageProxy) {
        if (showingCapturedResult || !liveAnalysisBusy.compareAndSet(false, true)) {
            image.close()
            return
        }
        val startMs = SystemClock.elapsedRealtime()
        try {
            val bitmap = yuvImageProxyToBitmap(image)
            image.close()
            if (bitmap == null) return

            try {
                val diagnosis = computeDiagnosis(bitmap)
                runOnUiThread {
                    if (showingCapturedResult) return@runOnUiThread
                    updateInferenceStats(startMs)
                    applyStatusColor(diagnosis.leafPresent, diagnosis.diseaseNames.isNotEmpty(), confidence = diagnosis.leafProb)
                    if (!diagnosis.leafPresent) {
                        binding.detectionTitle.text = "NOT A BANANA LEAF"
                        binding.detectionConfidence.text = ""
                        binding.detectionHealth.text = "Center a real banana leaf inside the frame"
                    } else if (diagnosis.diseaseNames.isEmpty()) {
                        binding.detectionTitle.text = "HEALTHY BANANA LEAF"
                        binding.detectionConfidence.text = getString(
                            R.string.leaf_confidence_format, diagnosis.leafProb * 100f
                        )
                        binding.detectionHealth.text = "Leaf in focus · Tap shutter to diagnose"
                    } else {
                        binding.detectionTitle.text = formatDiseaseSummary(
                            diagnosis.diseaseNames, diagnosis.diseaseConfidences
                        )
                        binding.detectionConfidence.text = getString(
                            R.string.leaf_confidence_format, diagnosis.leafProb * 100f
                        )
                        binding.detectionHealth.text = "Leaf in focus · Tap shutter to diagnose"
                    }
                }
            } finally {
                if (!bitmap.isRecycled) bitmap.recycle()
            }
        } catch (e: Exception) {
            // A dropped/unreadable live frame just means the overlay doesn't
            // update this cycle -- never worth surfacing to the user.
            android.util.Log.w("BananaLeaf_Live", "Live frame skipped: ${e.message}")
            image.close()
        } finally {
            liveAnalysisBusy.set(false)
        }
    }

    /**
     * ImageAnalysis frames arrive as YUV_420_888 (unlike ImageCapture's own
     * JPEG output), so they need their own decode path. Copies the Y/U/V
     * planes into a standard NV21 byte layout -- respecting each plane's
     * actual rowStride/pixelStride rather than assuming a tightly packed
     * buffer, since that assumption breaks (sheared/garbled frames) on a
     * number of real devices -- then reuses Android's own YuvImage -> JPEG
     * -> Bitmap pipeline and applies the same rotation correction as
     * [imageProxyToBitmap].
     */
    private fun yuvImageProxyToBitmap(image: ImageProxy): Bitmap? {
        if (image.format != ImageFormat.YUV_420_888) return null
        val width = image.width
        val height = image.height

        val yPlane = image.planes[0]
        val uPlane = image.planes[1]
        val vPlane = image.planes[2]

        val nv21 = ByteArray(width * height * 3 / 2)
        var pos = 0

        val yBuffer = yPlane.buffer
        val yRowStride = yPlane.rowStride
        for (row in 0 until height) {
            yBuffer.position(row * yRowStride)
            yBuffer.get(nv21, pos, width)
            pos += width
        }

        // NV21 wants interleaved V,U,V,U... at half resolution.
        val uBuffer = uPlane.buffer
        val vBuffer = vPlane.buffer
        val uRowStride = uPlane.rowStride
        val uPixelStride = uPlane.pixelStride
        val vRowStride = vPlane.rowStride
        val vPixelStride = vPlane.pixelStride
        val chromaHeight = height / 2
        val chromaWidth = width / 2

        for (row in 0 until chromaHeight) {
            val vRowStart = row * vRowStride
            val uRowStart = row * uRowStride
            for (col in 0 until chromaWidth) {
                nv21[pos++] = vBuffer.get(vRowStart + col * vPixelStride)
                nv21[pos++] = uBuffer.get(uRowStart + col * uPixelStride)
            }
        }

        val yuvImage = YuvImage(nv21, ImageFormat.NV21, width, height, null)
        val out = ByteArrayOutputStream()
        if (!yuvImage.compressToJpeg(Rect(0, 0, width, height), 90, out)) return null
        val bytes = out.toByteArray()
        val bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: return null

        val rotation = image.imageInfo.rotationDegrees
        if (rotation == 0) return bitmap
        val matrix = Matrix().apply { postRotate(rotation.toFloat()) }
        val rotated = Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
        if (rotated !== bitmap) bitmap.recycle()
        return rotated
    }

    override fun onPause() {
        super.onPause()
// Turn off torch when leaving the screen so it doesn't stay stuck on
        camera?.cameraControl?.enableTorch(false)
        isFlashOn = false
        updateTorchButton(false)
    }

    override fun onResume() {
        super.onResume()
        // If DetailsActivity's bottom nav asked for a specific section (My
        // Garden / Discover / LGU Connect) to be opened once we're back on
        // this scanner instance, honor that now.
        when (pendingSectionToOpen) {
            "garden" -> binding.navGarden.performClick()
            "discover" -> binding.navDiscover.performClick()
            "lgu" -> binding.navAccount.performClick()
        }
        pendingSectionToOpen = null
    }

    /**
     * Picks the most natural-sounding MALE voice available on-device for
     * whichever language was just set on [tts]. Android's Voice class has
     * no explicit "gender" field, so engines that support multiple voices
     * (e.g. Google's TTS engine, once its extra voice data is downloaded)
     * expose gender through the voice's own name instead -- this looks for
     * that naming pattern and, among the matches, prefers the highest
     * [Voice.getQuality] (its higher-quality "network"/enhanced voices sound
     * noticeably more natural than the default robotic one). If the current
     * engine has no voice it labels as male for this language, the call is
     * a no-op and speech keeps using whatever voice was already selected --
     * it never crashes or silences speech, it just can't do better than
     * what's installed on the device.
     */
    private fun selectNaturalMaleVoice() {
        val engine = tts ?: return
        val languageTag = engine.voice?.locale?.language ?: java.util.Locale.getDefault().language
        val voices = engine.voices ?: return

        val sameLanguage = voices.filter { it.locale.language == languageTag }
        android.util.Log.d(
            "BananaLeaf_TTS",
            "Voices for '$languageTag': " + sameLanguage.joinToString { v ->
                "${v.name} (quality=${v.quality}, network=${v.isNetworkConnectionRequired})"
            }.ifEmpty { "(none installed for this language)" }
        )

        val isMaleName = Regex(
            "(^|[^a-z])(male|man|m[0-9]|#male)([^a-z0-9]|$)",
            RegexOption.IGNORE_CASE
        )
        val isFemaleName = Regex(
            "(^|[^a-z])(female|woman|f[0-9]|#female)([^a-z0-9]|$)",
            RegexOption.IGNORE_CASE
        )

        val maleVoices = sameLanguage.filter { voice ->
            isMaleName.containsMatchIn(voice.name) && !isFemaleName.containsMatchIn(voice.name)
        }

        // Prefer an offline (local) male voice for reliability, but fall back
        // to a network one rather than giving up -- Google's engine often
        // only exposes gendered variants as network/enhanced voices for
        // lower-resource languages like Filipino, so requiring "local" here
        // was silently ruling out every male option on many devices.
        val bestMaleVoice = maleVoices
            .sortedWith(compareBy({ it.isNetworkConnectionRequired }, { -it.quality }))
            .firstOrNull()

        if (bestMaleVoice != null) {
            engine.voice = bestMaleVoice
            // A touch lower pitch and a slightly slower rate reads as a
            // calmer, more natural male voice instead of a rushed robotic one.
            engine.setPitch(0.92f)
            engine.setSpeechRate(0.98f)
            android.util.Log.d("BananaLeaf_TTS", "Selected male voice: ${bestMaleVoice.name}")
        } else {
            android.util.Log.d(
                "BananaLeaf_TTS",
                "No voice named male/man for '$languageTag' on this device/engine -- " +
                    "keeping the default voice. Check Settings > Accessibility > " +
                    "Text-to-speech output > (engine) > Install voice data, or switch " +
                    "the default TTS engine, to see if a male Filipino voice is available."
            )
        }
        // If no voice is explicitly labeled male for this language, leave the
        // engine's own default voice in place -- guessing wrong (e.g. picking
        // an unrelated variant voice) would sound worse than the default.
    }

    /**
     * Reads the currently open tab aloud, in Tagalog, offline. It goes
     * straight into that tab's own content only -- it does NOT repeat the
     * "Single Disease Detected"-style title or summary first, so tapping
     * Disease / Treatment / Recommendations (or the speaker icon) always
     * jumps directly to what was just tapped, e.g. tapping Treatment reads
     * only the Tagalog treatment text.
     */
    private fun speakCurrentResult() {
        if (!ttsReady) {
            Toast.makeText(this, "Voice engine is still starting up.", Toast.LENGTH_SHORT).show()
            return
        }
        if (lastDetectedSpokenText.isEmpty()) {
            Toast.makeText(this, "Scan a leaf first.", Toast.LENGTH_SHORT).show()
            return
        }
        val speech = DiseaseInfoTagalog.get(lastTopResultKey)
        val toSpeak = when (currentResultTab) {
            0 -> speech.overview
            1 -> speech.treatment
            else -> speech.recommendation
        }
        tts?.stop()
        tts?.speak(toSpeak, TextToSpeech.QUEUE_FLUSH, null, "leaf_result_utterance")
    }

    override fun onDestroy() {
        freezeFrameBitmap?.recycle()
        freezeFrameBitmap = null
        tts?.stop()
        tts?.shutdown()
        tts = null
        cameraExecutor.shutdown()
        super.onDestroy()
    }

    /**
     * Any tap anywhere on the screen interrupts speech that's currently
     * playing. Tapping the speaker button or a Disease/Treatment/
     * Recommendations tab still speaks -- those already stop-then-speak
     * inside speakCurrentResult(), so this just makes every OTHER tap
     * (camera area, handle, nav buttons, etc.) silence the voice too,
     * instead of letting it keep talking over whatever the user does next.
     */
    override fun dispatchTouchEvent(ev: android.view.MotionEvent): Boolean {
        if (ev.action == android.view.MotionEvent.ACTION_DOWN) {
            tts?.stop()
        }
        return super.dispatchTouchEvent(ev)
    }
}
